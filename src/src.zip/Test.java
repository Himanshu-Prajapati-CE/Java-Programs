
public class Test {
	public static void main(String[] args) {
		int x = 0;
		System.out.println((x++)+(++x));
		System.out.println((--x)+(x--));
	}
}
